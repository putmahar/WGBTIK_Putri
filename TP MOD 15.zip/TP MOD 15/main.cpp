#include "tree.h"
#include <iostream>

using namespace std;

int main()
{
    adrNode root = nil;

    int x[9] = {5,3,9,10,4,7,1,8,6};

    for (int i=0; i<9; i++){
        adrNode p = newNode_1301210537(x[i]);
        insertNode_1301210537(root, p);
    }

    cout << "===================================================" << endl;
    for (int i=0; i<9; i++){
        cout << x[i] << " ";
    }
    cout << endl;

    cout << endl;
    printf("\nPre Order\t\t: ");
    printPreOrder_1301210537(root);

    cout << endl;
    printf("\nDescendent of Node 9\t: ");
    printDescendant_1301210537(root, 9);

    cout << endl;
    printf("\nSum of BTS Info\t\t: ");
    cout << sumNode_1301210537(root);

    printf("\nNumber of Leaves\t: ");
    cout << countLeaves_1301210537(root);

    printf("\nHeight of Tree\t\t: ");
    cout << heightTree_1301210537(root);  //Koreksi tinggi pohon seharusnya 4, bukan 3
    cout << endl;
    cout << "===================================================" << endl;

    return 0;
}
